
/**
 * Dairy HACCP Analyzer - Single-file React Component
 * Tailored version: India guidance, Paneer flow, ISO/BRC fields, MD sensitivity, phosphatase guidance,
 * Tamil UI toggle, CSV/JSON export, TXT summary export, CCP helper.
 *
 * Drop this file into a React project (e.g., Vite/Next). Requires Tailwind + shadcn/ui or replace UI components.
 * This is a self-contained component for illustration; you may need to adapt imports to your project.
 */

import React, { useMemo, useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Download, Plus, Trash2, FileDown, Milk, ShieldAlert, CheckCircle2, Settings2, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

type HazardType = "Biological" | "Chemical" | "Physical" | "Allergen";
type Product = { id: string; name: string; description?: string };
type Step = { id: string; name: string; defaultMonitoring?: string };
type Hazard = {
  id: string;
  stepId: string;
  productId: string;
  type: HazardType;
  description: string;
  cause: string;
  preventiveMeasures: string;
  severity: number;
  likelihood: number;
  risk: number;
  isCCP: boolean;
  criticalLimits: string;
  monitoring: string;
  correctiveAction: string;
  verification: string;
  records: string;
  mdSensitivity?: string;
  isoNotes?: string;
};

const indianGuidance = {
  htst: { temp: 72, timeSec: 15, note: "FSSAI / Codex-aligned HTST guidance (confirm with local regulator)" },
  phosphatase: { pass: "negative", guidance: "Alkaline phosphatase negative indicates adequate pasteurization. Use AOAC method or validated rapid kit." },
  chilledStorage: { rawMilk: { maxC: 7 }, finishedGoods: { maxC: 4 } },
  yogurtPh: { max: 4.6 },
  metalDetector: { typicalSensitivities: "1.0–3.0 mm spheres (Fe), 1.5–3.5 mm (Non-Fe), validate per product" }
};

const defaultProducts: Product[] = [
  { id: crypto.randomUUID(), name: "Pasteurized Milk", description: "HTST 72°C/15s – default" },
  { id: crypto.randomUUID(), name: "Yogurt / Dahi", description: "Fermented milk" },
  { id: crypto.randomUUID(), name: "Paneer / Fresh Cheese", description: "Paneer: Coagulation → Drain → Press → Pack" },
  { id: crypto.randomUUID(), name: "Mozzarella / Pizza Cheese" },
  { id: crypto.randomUUID(), name: "Ghee / Butter Oil" },
  { id: crypto.randomUUID(), name: "Ice Cream" },
];

const defaultSteps: Step[] = [
  { id: "receiving", name: "Raw Milk Receiving", defaultMonitoring: "Temp ≤ 7°C; onsite antibiotic screen" },
  { id: "storage", name: "Chilled Storage", defaultMonitoring: "Tank temp 2–4°C" },
  { id: "clarification", name: "Clarification/Standardization", defaultMonitoring: "Separator rpm, fat% checks" },
  { id: "pasteurization", name: "Pasteurization/HTST", defaultMonitoring: "Temp/time chart; FDV" },
  { id: "coagulation", name: "Coagulation (Paneer/Cheese)", defaultMonitoring: "pH/coagulant dose; temperature" },
  { id: "drain_press", name: "Drain & Press (Paneer)", defaultMonitoring: "Drain time; pressing pressure" },
  { id: "fermentation", name: "Fermentation (Yogurt)", defaultMonitoring: "Set temp 42–45°C; pH trajectory" },
  { id: "cheese_make", name: "Cheese Make / Curd Handling", defaultMonitoring: "Curd temp; cutting time" },
  { id: "salting", name: "Salting / Brining", defaultMonitoring: "Brine salinity, temp" },
  { id: "packaging", name: "Packaging", defaultMonitoring: "Seal check; metal detection" },
  { id: "coldstore", name: "Cold Storage & Dispatch", defaultMonitoring: "Finished goods temp per spec" },
];

const hazardLibrary: Partial<Hazard & { stepId: string }>[] = [
  { stepId: "receiving", type: "Biological", description: "High SPC / mastitis-associated pathogens", cause: "Poor farm hygiene, delayed chilling", preventiveMeasures: "Approved milk supplier list; cooled transport", severity: 4, likelihood: 3, criticalLimits: "Raw milk ≤7°C; antibiotics ND" , monitoring: "MBRT/antibiotic strip", correctiveAction: "Segregate/reject; inform supplier", verification: "Supplier COA & audits", records: "milk_receipt_log" },
  { stepId: "pasteurization", type: "Biological", description: "Underprocessing leading to survival of pathogens", cause: "FDV failure, temp sensor drift", preventiveMeasures: "HTST validation; interlock with FDV", severity: 5, likelihood: 2, criticalLimits: `≥${indianGuidance.htst.temp}°C for ≥${indianGuidance.htst.timeSec}s`, monitoring: "Continuous temp chart; phosphatase test", correctiveAction: "Divert/reprocess; hold batch", verification: "Daily chart review; phosphatase checks", records: "pasteurization_charts" },
  { stepId: "coagulation", type: "Chemical", description: "Excess acidity or residual coagulant", cause: "Over-dosing; incorrect pH control", preventiveMeasures: "Validated dosing; pH control", severity: 3, likelihood: 2, criticalLimits: "pH within validated window", monitoring: "pH checks" , correctiveAction: "Adjust dose; discard if off-spec", verification: "COA of coagulant" },
  { stepId: "packaging", type: "Physical", description: "Metal fragments from filling line", cause: "Equipment wear, broken seal", preventiveMeasures: "MD + sieves; preventive maintenance", severity: 4, likelihood: 2, criticalLimits: indianGuidance.metalDetector.typicalSensitivities, monitoring: "Hourly MD test pieces", correctiveAction: "Stop line; isolate affected codes" }
];

const riskScore = (s: number, l: number) => s * l;
const decideCCP = (stepId: string, type: HazardType, risk: number) => {
  const highRisk = risk >= 12;
  const killSteps = ["pasteurization"];
  if (killSteps.includes(stepId) && type === "Biological" && highRisk) return true;
  if (stepId === "packaging" && type === "Physical" && highRisk) return true;
  return false;
};

const saveKey = "dairy-haccp-v2";

function downloadTXT(summary: { productName: string; hazards: Hazard[]; language: string }) {
  const lines = [];
  lines.push(`HACCP Summary — ${summary.productName}`);
  lines.push(`Exported: ${new Date().toLocaleString()}`);
  lines.push(`Language: ${summary.language}`);
  lines.push("");
  summary.hazards.forEach((h, i) => {
    lines.push(`${i+1}. Step: ${h.stepId}`);
    lines.push(`   Type: ${h.type}`);
    lines.push(`   Risk: ${h.risk} (S:${h.severity} × L:${h.likelihood})`);
    lines.push(`   CCP: ${h.isCCP ? "Yes" : "No"}`);
    if (h.description) lines.push(`   Desc: ${h.description}`);
    if (h.criticalLimits) lines.push(`   Critical limits: ${h.criticalLimits}`);
    if (h.mdSensitivity) lines.push(`   MD sensitivity: ${h.mdSensitivity}`);
    lines.push("");
  });
  const blob = new Blob([lines.join("\\n")], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${summary.productName.replaceAll(/\\s+/g,'_')}_haccp_summary.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function HACCPDairyApp() {
  const [products, setProducts] = useState<Product[]>([]);
  const [steps] = useState<Step[]>(defaultSteps);
  const [hazards, setHazards] = useState<Hazard[]>([]);
  const [activeProductId, setActiveProductId] = useState<string>("");
  const [filterText, setFilterText] = useState("");
  const [lang, setLang] = useState<'en'|'ta'>('en');

  useEffect(() => {
    const stored = localStorage.getItem(saveKey);
    if (stored) {
      const parsed = JSON.parse(stored);
      setProducts(parsed.products || defaultProducts);
      setHazards(parsed.hazards || []);
      setActiveProductId(parsed.activeProductId || (parsed.products?.[0]?.id ?? defaultProducts[0].id));
      setLang(parsed.lang || 'en');
    } else {
      setProducts(defaultProducts);
      setActiveProductId(defaultProducts[0].id);
      const seed: Hazard[] = hazardLibrary.map((h) => ({
        id: crypto.randomUUID(),
        stepId: (h as any).stepId,
        productId: defaultProducts[0].id,
        type: (h as any).type as HazardType,
        description: (h as any).description,
        cause: (h as any).cause || '',
        preventiveMeasures: (h as any).preventiveMeasures || '',
        severity: (h as any).severity || 3,
        likelihood: (h as any).likelihood || 3,
        risk: riskScore((h as any).severity || 3, (h as any).likelihood || 3),
        isCCP: decideCCP((h as any).stepId, (h as any).type, riskScore((h as any).severity || 3, (h as any).likelihood || 3)),
        criticalLimits: (h as any).criticalLimits || '',
        monitoring: (h as any).monitoring || '',
        correctiveAction: (h as any).correctiveAction || '',
        verification: (h as any).verification || '',
        records: (h as any).records || '',
        mdSensitivity: '',
        isoNotes: ''
      }));
      setHazards(seed);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(saveKey, JSON.stringify({ products, hazards, activeProductId, lang }));
  }, [products, hazards, activeProductId, lang]);

  const activeHazards = useMemo(() => hazards.filter(h => h.productId === activeProductId && (h.description + h.stepId + h.type + h.cause).toLowerCase().includes(filterText.toLowerCase())), [hazards, activeProductId, filterText]);
  const product = products.find(p => p.id === activeProductId);

  const addProduct = () => {
    const name = prompt(lang === 'ta' ? 'பொருளின் பெயர்' : 'Product name')?.trim();
    if (!name) return;
    const p: Product = { id: crypto.randomUUID(), name };
    setProducts(prev => [...prev, p]);
    setActiveProductId(p.id);
  };

  const addHazard = () => {
    const stepId = steps[0].id;
    const h: Hazard = {
      id: crypto.randomUUID(),
      stepId,
      productId: activeProductId,
      type: "Biological",
      description: "",
      cause: "",
      preventiveMeasures: "",
      severity: 3,
      likelihood: 3,
      risk: 9,
      isCCP: false,
      criticalLimits: "",
      monitoring: steps.find(s => s.id === stepId)?.defaultMonitoring || "",
      correctiveAction: "",
      verification: "",
      records: "",
      mdSensitivity: '',
      isoNotes: ''
    };
    setHazards(prev => [h, ...prev]);
  };

  const updateHazard = (id: string, patch: Partial<Hazard>) => {
    setHazards(prev => prev.map(h => h.id === id ? { ...h, ...patch, risk: riskScore(patch.severity ?? h.severity, patch.likelihood ?? h.likelihood), isCCP: decideCCP(h.stepId, patch.type ?? h.type, riskScore(patch.severity ?? h.severity, patch.likelihood ?? h.likelihood)) } : h));
  };

  const removeHazard = (id: string) => setHazards(prev => prev.filter(h => h.id !== id));

  const exportCSV = () => {
    const rows = [["Product","Process Step","Hazard Type","Hazard Description","Cause","Preventive Measures","Severity","Likelihood","Risk","CCP?","Critical Limits","Monitoring","Corrective Action","Verification","Records","MD Sensitivity","ISO/BRC Notes"]];
    rows.push(...hazards.filter(h => h.productId === activeProductId).map(h => [products.find(p => p.id === h.productId)?.name || '', steps.find(s => s.id === h.stepId)?.name || h.stepId, h.type, h.description, h.cause, h.preventiveMeasures, String(h.severity), String(h.likelihood), String(h.risk), h.isCCP ? 'Yes' : 'No', h.criticalLimits, h.monitoring, h.correctiveAction, h.verification, h.records, h.mdSensitivity || '', h.isoNotes || '']));
    const csv = rows.map(r => r.map(v => `\"${String(v).replaceAll('"','\"\"')}\"`).join(",")).join("\\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(product?.name || 'product').toLowerCase().replace(/\\s+/g,'_')}_haccp_export.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportJSON = () => {
    const data = { products, steps, hazards: hazards.filter(h => h.productId === activeProductId) };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(product?.name || 'product').toLowerCase().replace(/\\s+/g,'_')}_haccp.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportSummary = () => {
    const summary = { productName: product?.name || 'product', hazards: hazards.filter(h => h.productId === activeProductId), language: lang };
    downloadTXT(summary);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white p-6">
      <div className="mx-auto max-w-7xl grid gap-6">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Milk className="w-8 h-8" />
            <div>
              <h1 className="text-2xl font-semibold">Dairy HACCP Analyzer (Tailored)</h1>
              <p className="text-sm text-muted-foreground">India guidance, paneer flow, ISO/BRC notes, MD fields, phosphatase guidance, Tamil UI.</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={addProduct}><Plus className="w-4 h-4 mr-1"/>Add Product</Button>
            <Button onClick={exportCSV}><FileDown className="w-4 h-4 mr-1"/>Export CSV</Button>
            <Button onClick={exportJSON} variant="outline"><Download className="w-4 h-4 mr-1"/>Export JSON</Button>
            <Button onClick={exportSummary} ><Download className="w-4 h-4 mr-1"/>Export Summary</Button>
            <Button variant="ghost" onClick={()=>setLang(l => l==='en'?'ta':'en')} title={lang==='en'?'Switch to Tamil':'Switch to English'}><Globe className="w-4 h-4"/></Button>
          </div>
        </header>

        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="grid md:grid-cols-[320px_1fr] gap-6">
          <Card className="h-fit sticky top-4">
            <CardHeader>
              <CardTitle className="text-base">Product & Filters</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid gap-2">
                <Label>Active product</Label>
                <Select value={activeProductId} onValueChange={setActiveProductId}>
                  <SelectTrigger>
                    <SelectValue placeholder={'Select product'} />
                  </SelectTrigger>
                  <SelectContent className="max-h-64">
                    {products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                {product?.description && <p className="text-xs text-muted-foreground">{product.description}</p>}
              </div>

              <div className="grid gap-2">
                <Label>Quick search</Label>
                <Input placeholder={'hazard, step, cause...'} value={filterText} onChange={(e)=>setFilterText(e.target.value)} />
              </div>

              <div className="grid gap-2">
                <Label>Common steps</Label>
                <div className="flex flex-wrap gap-1">{steps.map(s => <span key={s.id} className="px-2 py-1 rounded-full bg-muted text-xs">{s.name}</span>)}</div>
              </div>

              <div className="grid gap-2 text-xs text-muted-foreground">
                <div><strong>India notes:</strong></div>
                <div>HTST: ≥{indianGuidance.htst.temp}°C/{indianGuidance.htst.timeSec}s • Phosphatase: {indianGuidance.phosphatase.pass}</div>
                <div>Chilled raw milk ≤{indianGuidance.chilledStorage.rawMilk.maxC}°C • Finished ≤{indianGuidance.chilledStorage.finishedGoods.maxC}°C</div>
                <div>Metal detector guidance: {indianGuidance.metalDetector.typicalSensitivities}</div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-6">
            <Card>
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2"><ShieldAlert className="w-5 h-5"/>Hazards & Controls</CardTitle>
                <Button onClick={addHazard}><Plus className="w-4 h-4 mr-1"/>Add Hazard</Button>
              </CardHeader>
              <CardContent className="grid gap-4">
                {activeHazards.length===0 && <div className="text-sm text-muted-foreground">No hazards yet for this product.</div>}

                <div className="grid gap-4">
                  {activeHazards.map(h => (
                    <motion.div key={h.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-2xl border p-4 bg-white shadow-sm">
                      <div className="flex items-start justify-between gap-4">
                        <div className="grid gap-3 flex-1">
                          <div className="grid md:grid-cols-3 gap-3">
                            <div>
                              <Label>Process Step</Label>
                              <Select value={h.stepId} onValueChange={(v)=>updateHazard(h.id,{ stepId: v })}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent className="max-h-64">{steps.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                              </Select>
                            </div>
                            <div>
                              <Label>Hazard Type</Label>
                              <Select value={h.type} onValueChange={(v)=>updateHazard(h.id,{ type: v as HazardType })}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{(["Biological","Chemical","Physical","Allergen"] as HazardType[]).map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                              </Select>
                            </div>
                            <div>
                              <Label>Description</Label>
                              <Input value={h.description} onChange={(e)=>updateHazard(h.id,{ description: e.target.value })} placeholder={'e.g., Survival of pathogens'} />
                            </div>
                          </div>

                          <div className="grid md:grid-cols-3 gap-3">
                            <div>
                              <Label>Cause / Source</Label>
                              <Input value={h.cause} onChange={(e)=>updateHazard(h.id,{ cause: e.target.value })} placeholder={'e.g., insufficient holding time'} />
                            </div>
                            <div>
                              <Label>Preventive Measures</Label>
                              <Input value={h.preventiveMeasures} onChange={(e)=>updateHazard(h.id,{ preventiveMeasures: e.target.value })} placeholder={'e.g., chart recorder, alarms'} />
                            </div>
                            <div className="grid grid-cols-3 gap-3">
                              <div>
                                <Label>Severity (1–5)</Label>
                                <Input type="number" min={1} max={5} value={h.severity} onChange={(e)=>updateHazard(h.id,{ severity: Number(e.target.value) })} />
                              </div>
                              <div>
                                <Label>Likelihood (1–5)</Label>
                                <Input type="number" min={1} max={5} value={h.likelihood} onChange={(e)=>updateHazard(h.id,{ likelihood: Number(e.target.value) })} />
                              </div>
                              <div>
                                <Label>Risk = S × L</Label>
                                <div className="h-10 flex items-center px-3 rounded-lg border bg-muted/30 text-sm">{h.risk}</div>
                              </div>
                            </div>
                          </div>

                          <div className="grid md:grid-cols-2 gap-3">
                            <div>
                              <Label>Critical Limits (if CCP)</Label>
                              <Input value={h.criticalLimits} onChange={(e)=>updateHazard(h.id,{ criticalLimits: e.target.value })} placeholder={'e.g., ≥72°C for ≥15s'} />
                            </div>
                            <div>
                              <Label>Monitoring</Label>
                              <Input value={h.monitoring} onChange={(e)=>updateHazard(h.id,{ monitoring: e.target.value })} placeholder={'e.g., continuous temp record'} />
                            </div>
                          </div>

                          <div className="grid md:grid-cols-3 gap-3">
                            <div>
                              <Label>Corrective Action</Label>
                              <Textarea value={h.correctiveAction} onChange={(e)=>updateHazard(h.id,{ correctiveAction: e.target.value })} rows={2} />
                            </div>
                            <div>
                              <Label>Verification</Label>
                              <Textarea value={h.verification} onChange={(e)=>updateHazard(h.id,{ verification: e.target.value })} rows={2} />
                            </div>
                            <div>
                              <Label>Records</Label>
                              <Textarea value={h.records} onChange={(e)=>updateHazard(h.id,{ records: e.target.value })} rows={2} />
                            </div>
                          </div>

                          <div className="grid md:grid-cols-2 gap-3">
                            <div>
                              <Label>MD Sensitivity (mm)</Label>
                              <Input value={h.mdSensitivity || ''} onChange={(e)=>updateHazard(h.id,{ mdSensitivity: e.target.value })} placeholder={'e.g., 2.0 mm Fe / validate per product'} />
                            </div>
                            <div>
                              <Label>ISO22000 / BRCGS notes</Label>
                              <Input value={h.isoNotes || ''} onChange={(e)=>updateHazard(h.id,{ isoNotes: e.target.value })} placeholder={'e.g., Clause references, validation notes'} />
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col items-end gap-3 w-44 shrink-0">
                          <div className="flex items-center gap-2">{h.isCCP ? (<Badge className="bg-green-600 text-white"><CheckCircle2 className="w-3 h-3 mr-1"/>CCP</Badge>) : (<Badge variant="outline">PRP/OPRP</Badge>)}</div>
                          <div className="text-xs text-muted-foreground">
                            <div>Step: <strong>{steps.find(s => s.id === h.stepId)?.name || h.stepId}</strong></div>
                            <div>Type: <strong>{h.type}</strong></div>
                            <div>Risk band: <strong>{h.risk >= 12 ? 'High' : h.risk >= 8 ? 'Medium' : 'Low'}</strong></div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="icon" onClick={()=>updateHazard(h.id,{ isCCP: !h.isCCP })} title={'Toggle CCP'}><ShieldAlert className="w-4 h-4" /></Button>
                            <Button variant="destructive" size="icon" onClick={()=>removeHazard(h.id)} title={'Remove'}><Trash2 className="w-4 h-4" /></Button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2"><Settings2 className="w-5 h-5"/>Risk Matrix & Guidance</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-4 text-sm text-muted-foreground">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="grid gap-2">
                    <div className="font-medium text-slate-800">Risk Bands (S × L)</div>
                    <ul className="list-disc pl-6">
                      <li>1–7: Low – manage via PRPs / GMP.</li>
                      <li>8–11: Medium – consider OPRP, tighten controls.</li>
                      <li>≥12: High – typically CCP if control is at a decisive step (e.g., pasteurization, metal detection).</li>
                    </ul>
                    <div className="mt-2">CCP Justification template (brief):</div>
                    <div className="rounded p-2 border bg-white text-xs">
                      1) Describe the hazard & why it is significant.&#10;2) Explain how the step prevents/eliminates the hazard.&#10;3) Provide the critical limit (scientific/regulatory basis).&#10;4) Describe monitoring, corrective action & verification.
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <div className="font-medium text-slate-800">Typical Dairy Critical Limits (examples)</div>
                    <ul className="list-disc pl-6">
                      <li>HTST milk: ≥{indianGuidance.htst.temp}°C for ≥{indianGuidance.htst.timeSec}s; phosphatase negative.</li>
                      <li>Yogurt: pH ≤ {indianGuidance.yogurtPh.max} within validated time; chilled ≤ {indianGuidance.chilledStorage.finishedGoods.maxC}°C post-set.</li>
                      <li>Metal detection: sensitivities per validation (document MD sensitivity per product).</li>
                      <li>Paneer: control coagulant dosing, maintain drain/press times to avoid Listeria growth risk in warm storage.</li>
                    </ul>
                    <div className="text-xs">Note: adapt to your national regulations & product specifications. Use supplier COAs, calibration & validation records to support CCP claims (ISO22000 / BRCGS).</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        <footer className="text-center text-xs text-muted-foreground pt-4">Built for dairy HACCP teams • Data saved locally • Export CSV/JSON/TXT summary • Tailored for India & BRC/ISO notes</footer>
      </div>
    </div>
  );
}
