import HACCPDairyApp from "./dairy_haccp_analyzer";

export default function App() {
  return <HACCPDairyApp />;
}