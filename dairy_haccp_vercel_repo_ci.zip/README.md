# Dairy HACCP Analyzer

This repo is ready for **deployment on Vercel**.

## 🚀 How to Deploy

1. Push this project to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/dairy-haccp-analyzer.git
   git push -u origin main
   ```

2. Go to [Vercel](https://vercel.com), import the repository, and click **Deploy**.

3. Done! Your app will be live at:
   ```
   https://dairy-haccp-analyzer.vercel.app
   ```

## Development
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Tech Stack
- React + Vite
- TailwindCSS
- jsPDF (for PDF exports)
