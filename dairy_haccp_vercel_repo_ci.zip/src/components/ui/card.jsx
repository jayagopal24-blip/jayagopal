export function Card({ children, className = "" }) {
  return <div className={`rounded-2xl shadow p-4 bg-white ${className}`}>{children}</div>;
}
export function CardHeader({ children }) {
  return <div className="font-bold text-lg mb-2">{children}</div>;
}
export function CardContent({ children }) {
  return <div>{children}</div>;
}