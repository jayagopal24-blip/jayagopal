export function Select({ children, ...props }) {
  return <select {...props} className="border p-2 rounded w-full">{children}</select>;
}
export function SelectTrigger({ children }) { return <>{children}</>; }
export function SelectContent({ children }) { return <>{children}</>; }
export function SelectItem({ children, ...props }) { return <option {...props}>{children}</option>; }
export function SelectValue({ children }) { return <>{children}</>; }